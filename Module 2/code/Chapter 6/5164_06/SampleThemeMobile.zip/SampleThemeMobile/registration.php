<?php
/**
 * SampleTheme
 *
 * @package Genmato_SampleThemeMobile
 * @author  Vladimir Kerkhoff <support@genmato.com>
 * @created 2016-02-01
 * @copyright Copyright (c) 2016 Genmato BV, https://genmato.com.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::THEME,
        'frontend/Genmato/mobile',
        __DIR__
    );