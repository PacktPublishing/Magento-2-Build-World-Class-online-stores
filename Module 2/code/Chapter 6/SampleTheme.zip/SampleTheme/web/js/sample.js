require([
    'jquery',
], function ($) {
    jQuery(document).ready(function () {
        // You jQuery code here
    });
});